#!/usr/bin/env python3
import requests 
import json
import base64
import pandas as pd
from sqlalchemy import create_engine, text
from datetime import datetime
import traceback
import sys

print("\n#########################################################")
print(datetime.now())

# PowerSchool API credentials
client_id = 'your_client_id'
client_secret = 'your_client_secret'

def get_access_token(client_id, client_secret):
    """Return Access Token to authorize API endpoints"""
    try:
        auth_url = "https://your-powerschool-domain.com/oauth/access_token/"
        message = f"{client_id}:{client_secret}"
        message_bytes = message.encode('ascii')
        base64_message = base64.b64encode(message_bytes).decode()
        
        headers = {
            'Authorization': f"Basic {base64_message}",
            'Content-Type': "application/x-www-form-urlencoded;charset=UTF-8"
        }
        data = {'grant_type': "client_credentials"}

        res = requests.post(auth_url, headers=headers, data=data)
        
        if res.status_code != 200:
            error_msg = f"Failed to get access token. Status code: {res.status_code}, Response: {res.text}"
            raise Exception(error_msg)
            
        return res.json()["access_token"]
    except Exception as e:
        error_msg = f"Error getting access token: {str(e)}"
        error_tb = traceback.format_exc()
        print(error_msg)
        print(error_tb)
        raise

def ActivityData(headers):
    """Fetches activity data from PowerSchool API"""
    try:
        base_url = "https://your-powerschool-domain.com/ws/schema/table/Activities?projection=StudentsDCID,peace_warriors"
        all_records = []
        page = 1
        pagesize = 100
        
        while True:
            url = f"{base_url}&page={page}&pagesize={pagesize}"
            response = requests.get(url, headers=headers)
            data = response.json()
            
            if 'record' not in data or not data['record']:
                break

            records = [{
                'studentsdcid': d.get('tables', {}).get('activities', {}).get('studentsdcid'),
                'peacewarriors': d.get('tables', {}).get('activities', {}).get('peace_warriors'),
            } for d in data['record']]

            df = pd.DataFrame(records)
            print("Length of Activity Data: ", len(df))
            all_records.append(df)
            page += 1
            
        return pd.concat(all_records)
    except Exception as e:
        error_msg = f"Error in ActivityData: {str(e)}"
        error_tb = traceback.format_exc()
        print(error_msg)
        print(error_tb)
        raise

def import_df_to_db(df):
    """Import DataFrame to database"""
    try:
        db_config = {
            "user": "your_db_username",      
            "pass": "your_db_password",
            "host": "your_db_host",
            "database": "your_db_name"
        }

        engine = create_engine(f"mysql+mysqlconnector://{db_config['user']}:{db_config['pass']}@{db_config['host']}/{db_config['database']}")
        
        try:
            with engine.connect() as conn:
                conn.execute(text("TRUNCATE TABLE student_peacewarriors"))
            df.to_sql('student_peacewarriors', con=engine, if_exists='append', index=False)
            print("Data successfully written to student_peacewarriors table")
        finally:
            engine.dispose()
            
    except Exception as e:
        error_msg = f"Error in import_df_to_db: {str(e)}"
        error_tb = traceback.format_exc()
        print(error_msg)
        print(error_tb)
        raise

def main():
    """Main function to run the script"""
    try:
        print("\nStarting script execution...")
        print("=========================================")
        
        print("\n[1/3] Getting PowerSchool access token...")
        token = get_access_token(client_id, client_secret)
        print('Token obtained successfully')

        print("\n[2/3] Setting up API headers...")
        headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

        print("\n[3/3] Fetching activity data from PowerSchool...")
        activity_df = ActivityData(headers)
        print(f"Successfully fetched {len(activity_df)} records")

        print("\nImporting data to database...")
        import_df_to_db(activity_df)
        print("\nScript completed successfully!")
        print("=========================================")
        
    except Exception as e:
        print("\nScript encountered an error!")
        error_msg = str(e)
        error_tb = traceback.format_exc()
        print(f"Error details: {error_msg}")
        print(error_tb)
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        error_msg = str(e)
        error_tb = traceback.format_exc()
        print(f"Critical error: {error_msg}")
        print(error_tb)
        sys.exit(1)