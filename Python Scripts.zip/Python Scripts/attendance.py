#!/usr/bin/env python3
import requests 
import json
import base64
import xmltodict
import pandas as pd
from sqlalchemy import create_engine, text
from datetime import datetime
import traceback

print("\n###################################################")
print("date :",datetime.now())
client_id = 'Your_Id'
client_secret = 'Your_Secret'
auth_header = {}
auth_data = {}

"""
Return Access Token to authorize API endpoints
"""
def get_access_token(client_id, client_secret):
    try:
        # # Setting up the URL for authentication
        auth_url = "https://nlcphs.powerschool.com/oauth/access_token/"
        message = f"{client_id}:{client_secret}"

        # The message is encoded to bytes using the ASCII encoding scheme.
        message_bytes = message.encode('ascii')

        # The bytes are then base64 encoded to create a string that will be included in the authentication header.
        base64_bytes = base64.b64encode(message_bytes)

        base64_message = base64_bytes.decode()
        auth_header['Authorization'] = "Basic "+base64_message
        auth_header['Content-Type'] ="application/x-www-form-urlencoded;charset=UTF-8"
        auth_data['grant_type'] = "client_credentials"

        res = requests.post(auth_url, headers=auth_header, data=auth_data)
        response_obj = res.json()

        print(response_obj)
        # print(json.dumps(response_obj, indent=2))

        # The access_token is extracted from the response JSON object and stored for use in subsequent requests.
        access_token = response_obj["access_token"]
        return access_token
    except Exception as e:
        error_msg = f"Error getting access token: {str(e)}"
        error_tb = traceback.format_exc()
        print(error_msg)
        print(error_tb)
        raise

token = get_access_token(client_id, client_secret)
print('Token : ',token)


headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/json",
    "Content-Type": "application/json"
}

def get_dataframe(records):
    try:
        df = pd.DataFrame(records)
        return df
    except Exception as e:
        error_msg = f"Error converting records to DataFrame: {str(e)}"
        error_tb = traceback.format_exc()
        print(error_msg)
        print(error_tb)
        raise

def Attendance_data():
    try:
        """
        Fetches course data (ID, School ID, Course Number, Course Name) from a paginated API and combines it into a DataFrame.

        Returns:
            pd.DataFrame: DataFrame containing all course records.
        """
        base_url = "https://nlcphs.powerschool.com/ws/schema/table/Attendance?projection=DCID,Attendance_CodeID,YearID,StudentID,Att_Mode_Code,Att_Date&q=Att_Mode_Code==ATT_ModeDaily;YearID==34"
        all_records = []
        page =1
        pagesize=100
        while True:
            url = f"{base_url}&page={page}&pagesize={pagesize}"
            response = requests.get(url, headers=headers)
            all_data = response.json()
            # print(all_data)
            if 'record' in list(all_data.keys()):
                records = all_data['record']
            if len(records)==0:
                break
           
            result = [{
                'dcid': d['tables']['attendance']['dcid'],
                'studentid':d['tables']['attendance']['studentid'],
                'att_mode_code':d['tables']['attendance']['att_mode_code'],
                'attendance_codeid':d['tables']['attendance']['attendance_codeid'],
                'yearid':d['tables']['attendance']['yearid'],
                'att_date':d['tables']['attendance']['att_date'],
            }
             for d in records
             ]  
            df = get_dataframe(result)
            all_records.append(df)

            page+=1
        dfs = pd.concat(all_records)
        return dfs
    except Exception as e:
        error_msg = f"Error in Attendance_data: {str(e)}"
        error_tb = traceback.format_exc()
        print(error_msg)
        print(error_tb)
        raise

attendance_df = Attendance_data()

def import_df_to_db(df):
    try:
        # Define database credentials separately
        db_user = "Your_username"      

        # This is encoded password
        db_pass = "Your_password" 
        host = "Your_IP"     # replace with actual host IP
        database = "Your_Database_Name" # replace with actual database name

        # Create the connection engine with SQLAlchemy
        engine = create_engine(f"mysql+mysqlconnector://{db_user}:{db_pass}@{host}/{database}")
        try:
            # # Step 1: Connect and delete records where startdate >= date_threshold
            with engine.connect() as conn:
                
                delete_query = text("TRUNCATE TABLE student_attendance")
                conn.execute(delete_query)
                # print(f"Records with startdate >= {date_threshold} have been deleted.")
            # Step 2: Append new data from DataFrame to the table
            df.to_sql('student_attendance', con=engine, if_exists='append', index=False)
            print("New data successfully written to the student_attendance table.")

        except Exception as e:
            error_msg = f"Database error: {str(e)}"
            error_tb = traceback.format_exc()
            print(error_msg)
            print(error_tb)
            raise

    except Exception as e:
        error_msg = f"Error in import_df_to_db: {str(e)}"
        error_tb = traceback.format_exc()
        print(error_msg)
        print(error_tb)
        raise

    finally:
        # Step 3: Dispose of the engine to close the connection
        engine.dispose()

import_df_to_db(attendance_df)