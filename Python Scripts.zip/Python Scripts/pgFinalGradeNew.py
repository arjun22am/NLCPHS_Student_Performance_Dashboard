#!/usr/bin/env python3
import requests 
import json
import base64
import xmltodict
import pandas as pd
from sqlalchemy import create_engine, text
import datetime

print("\n#############################################################################")
print("date :", datetime.datetime.now())
client_id = 'Your_Id'
client_secret = 'Your_Secret'
auth_header = {}
auth_data = {}


"""
Return Access Token to authorize API endpoints
"""
def get_access_token(client_id, client_secret):
    # # Setting up the URL for authentication
    auth_url = "https://nlcphs.powerschool.com/oauth/access_token/"
    message = f"{client_id}:{client_secret}"

    # The message is encoded to bytes using the ASCII encoding scheme.
    message_bytes = message.encode('ascii')

    # The bytes are then base64 encoded to create a string that will be included in the authentication header.
    base64_bytes = base64.b64encode(message_bytes)

    base64_message = base64_bytes.decode()
    auth_header['Authorization'] = "Basic "+base64_message
    auth_header['Content-Type'] ="application/x-www-form-urlencoded;charset=UTF-8"
    auth_data['grant_type'] = "client_credentials"

    res = requests.post(auth_url, headers=auth_header, data=auth_data)
    response_obj = res.json()
    
    print(response_obj)
    # print(json.dumps(response_obj, indent=2))

    # The access_token is extracted from the response JSON object and stored for use in subsequent requests.
    access_token = response_obj["access_token"]
    return access_token

token = get_access_token(client_id, client_secret)
print('Token : ',token)


headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/json",
    "Content-Type": "application/json"
}

def get_dataframe(records):
    df = pd.DataFrame(records)
    return df

def course_data():
    """
    Fetches course data (ID, School ID, Course Number, Course Name) from a paginated API and combines it into a DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing all course records.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/Courses?projection=ID,SchoolID,Course_Name,Course_Number"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        if 'record' in list(all_data.keys()):
            records = all_data['record']
        if len(records)==0:
            break

        result = [{
            'ID': d['tables']['courses']['id'],
            'School_id':d['tables']['courses']['schoolid'],
            'Course_number':d['tables']['courses']['course_number'],
            'Course_name':d['tables']['courses']['course_name'],
        }
         for d in records
         ]  
        df = get_dataframe(result)
        all_records.append(df)

        page+=1
    dfs = pd.concat(all_records)
    return dfs

course_df = course_data()
print("Course data fetched successfully")

def section_data():
    """
    Fetches section data (School ID, Section Number, Course Number, Teacher, Term ID, Grade Level) from a paginated API,
    filters for specific terms, and combines results into a DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing filtered section records for Term IDs 3400, 3401, and 3402.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/Sections?projection=ID,Section_Number,Course_Number,Teacher,TermID,No_of_students,Grade_Level,SchoolID,ProgramID&q=TermID=gt=3399"
 
    #base_url = "https://nlcphs.powerschool.com/ws/schema/table/Sections?projection=ID,Section_Number,Course_Number,Teacher,TermID,No_of_students,Grade_Level,SchoolID,ProgramID"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        if 'record' in list(all_data.keys()):
            records = all_data['record']
          
        if len(records)==0:
            break

        result = [{
            'School_id':d['tables']['sections']['schoolid'],
            'ID': d['tables']['sections']['id'],
            'Teacher':d['tables']['sections']['teacher'],
            'Section_number':d['tables']['sections']['section_number'],
            'Course_number':d['tables']['sections']['course_number'],
            'TermId': d['tables']['sections']['termid'],
            'Grade_Level': d['tables']['sections']['grade_level'],
        }
         for d in records
         ]     
      
        df = get_dataframe(result)
        # print(df)
        all_records.append(df)

        page+=1
    dfs = pd.concat(all_records)
    section_df_f = dfs[dfs['TermId'].isin(['3400', '3401', '3402'])]
    section_df_f
    return section_df_f

section_df = section_data()
print("Section Data fetched successfully")

section_course = pd.merge(section_df, course_df, on=['Course_number'], how='inner')


def pgfinalgrades():
    """
    Fetches paginated final grade data (ID, Student ID, Section ID, Grade, Percent, etc.) from the PowerSchool API, 
    starting from August 1, 2024, and combines it into a DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing all fetched final grade records.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/PGFinalGrades?projection=dcid,ID,SectionID,StudentID,FinalGradeName,Grade,Citizenship,Percent,Points,PointsPossible,StartDate,EndDate,Comment,LastGradeUpdate,VarCredit,OverrideFG,GradebookType,IP_ADDRESS,WHOMODIFIEDID,TRANSACTION_DATE&q=StartDate=gt=2024-08-01"
    # &page=2&pagesize=100"
    # response = requests.get(url, headers=headers)
    # data = response.json()
    count = 0
    all_records = []
    page =1
    pagesize=100
    while True:
        # print('Count : ',count)
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        
        if 'record' in list(all_data.keys()):
            records = all_data['record']

        if len(records)==0:
            break

        result = [{
                'id':d['tables']['pgfinalgrades']['id'],
                'Student_id':d['tables']['pgfinalgrades']['studentid'],
                'Section_id':d['tables']['pgfinalgrades']['sectionid'],
                'transaction_date':d['tables']['pgfinalgrades']['transaction_date'],
                # 'varcredit':d['tables']['pgfinalgrades']['varcredit'],
                'finalgradename':d['tables']['pgfinalgrades']['finalgradename'],
                'startdate':d['tables']['pgfinalgrades']['startdate'],
                'enddate':d['tables']['pgfinalgrades']['enddate'],
                'lastgradeupdate':d['tables']['pgfinalgrades']['lastgradeupdate'],
                'Grade':d['tables']['pgfinalgrades']['grade'],
                'percent':d['tables']['pgfinalgrades']['percent'],
                # 'pointspossible':d['tables']['pgfinalgrades']['pointspossible'],
                'points':d['tables']['pgfinalgrades']['points'],
            }
                    for d in records
            ]

        df = get_dataframe(result)
        # print(df)
        all_records.append(df)

        page+=1
        count+=1
    dfs = pd.concat(all_records)
    return dfs

pg_final_grade = pgfinalgrades()
print("pgfinalgradeNew data fetched successfully")

def student_data():
    """
    Fetches paginated student data (School ID, Name, Student Number, Grade, etc.) from the PowerSchool API, 
    filters for enrolled students, and returns a formatted DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing enrolled student records with columns: SchoolID, Student Name, 
                      Student_id, Student_Number, and Grade_level.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/Students?projection=SchoolID,ID,DCID,Student_Number,Student_AllowWebAccess,First_Name,Last_Name,Grade_Level,Student_Web_ID,Student_Web_Password,State_StudentNumber,Gender,DOB,Enroll_Status,Street,City,State,Zip,Emerg_Contact_1,Guardian_StudentCont_guid,Web_ID,Web_Password,FedEthnicity,LunchStatus&q=Enroll_Status==0"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        if 'record' in list(all_data.keys()):
            records = all_data['record']
        if len(records)==0:
            break

        result = [
        {'SchoolID': d['tables']['students']['schoolid'],
         'Last_Name': d['tables']['students']['last_name'],
         'First_Name': d['tables']['students']['first_name'],
         'Student_id': d['tables']['students']['id'],
         'Student_Number': d['tables']['students']['student_number'],
         'Grade':d['tables']['students']['grade_level'],
         'Enroll_Status': d['tables']['students']['enroll_status'],
        }
        for d in records]

        df = get_dataframe(result)
        all_records.append(df)

        page+=1


    dfs = pd.concat(all_records)
    dfs['Student Name'] = dfs['Last_Name']+ ' '+dfs['First_Name']
    # Create a copy of the subset where Enroll_Status is '0'
    # student_df = dfs[dfs['Enroll_Status'] == '0'].copy()
    student_df = dfs
    # Drop unnecessary columns
    student_df.drop(columns=['Last_Name', 'First_Name', 'Enroll_Status'], inplace=True)

    # Rename the 'Grade' column to 'Grade_level'
    student_df.rename(columns={'Grade': 'Grade_level'}, inplace=True)
    return student_df

student_df = student_data()
print("student data fetched successfully")

# Merge pgFinalGrade and Student data
pg_final_grade['Student_id'] = pg_final_grade['Student_id'].astype(int)
student_df['Student_id'] = student_df['Student_id'].astype(int)
pg_grade_student = pd.merge(pg_final_grade, student_df, on='Student_id', how='left')

# Merge pg_grade_student & section_course
section_final_grade = pd.merge(pg_grade_student, section_course, left_on=['SchoolID','Section_id'], right_on=['School_id_x', 'ID_x'], how='inner')


section_final_grade.drop(columns=['ID_x', 'ID_y', 'Grade_Level'], inplace=True)
section_final_grade.rename(columns={'id':'pg_id'}, inplace=True)

def school_staff():
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/SchoolStaff?projection=Users_DCID,ID,StaffStatus,SchoolID"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        # print(all_data)
        if 'record' in list(all_data.keys()):
            records = all_data['record']
            # print(records)
        if len(records)==0:
            break
           
        result = [
        {'SchoolID': d['tables']['schoolstaff']['schoolid'],
         'Teacher_id': d['tables']['schoolstaff']['id'],
         'users_dcid': d['tables']['schoolstaff']['users_dcid'],
        }
        for d in records]

        df = get_dataframe(result)
        all_records.append(df)

        page+=1
        # pagesize+=100

    dfs = pd.concat(all_records)
    return dfs

school_staff_df = school_staff()
print("school staff data fetched successfully")
def user_data():
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/Users?projection=dcid,First_Name,Middle_Name,Last_Name,TeacherNumber,HomeSchoolId"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        # print(all_data)
        if 'record' in list(all_data.keys()):
            records = all_data['record']
            # print(records)
        if len(records)==0:
            break
           
        result = [
        {'dcid': d['tables']['users']['dcid'],
         'First_name': d['tables']['users']['first_name'],
        'Last_name': d['tables']['users']['last_name'],
        'Middle_name': d['tables']['users']['middle_name'],
         'School_id': d['tables']['users']['homeschoolid'],
        }
        for d in records]

        df = get_dataframe(result)
        all_records.append(df)

        page+=1
        # pagesize+=100

    dfs = pd.concat(all_records)
    return dfs

user_df = user_data()
print("user data fetched successfully")

# Merge section_final_grade & school_staff_df 
section_staff_df = pd.merge(section_final_grade, school_staff_df, left_on=['Teacher'], right_on=['Teacher_id'], how='left')

# Merge section_staff_df & user_df
final_df = pd.merge(section_staff_df, user_df, left_on=['users_dcid'], right_on=['dcid'], how='left')
final_df['Teacher_Name'] = final_df['Last_name']+ ', '+final_df['First_name']
final_df.drop(columns=['users_dcid', 'dcid',
       'First_name', 'Last_name', 'Middle_name', 'Teacher'], inplace=True)

final_df.rename(columns={'SchoolID_x':'School_id', 'Student Name':'Student_Name'}, inplace=True)
final_df = final_df.loc[:, ~final_df.columns.duplicated()]

final_df = final_df[['pg_id', 'Student_id', 'Section_id', 'transaction_date',
       'finalgradename', 'startdate', 'enddate', 'lastgradeupdate', 'Grade',
       'percent', 'points', 'Student_Number', 'Grade_level',
       'Student_Name', 'Section_number', 'Course_number',
       'TermId', 'Course_name', 'Teacher_id', 'School_id', 'Teacher_Name']]

def import_df_to_db(df):
    # Define database credentials separately
    db_user = "Your_Username"      

    # This is encoded password
    db_pass = "Your_password" 
    host = "Your_IP"     # replace with actual host IP
    database = "Your_Database_Name" # replace with actual database name

    # Create the connection engine with SQLAlchemy
    engine = create_engine(f"mysql+mysqlconnector://{db_user}:{db_pass}@{host}/{database}")

    # Define the date threshold
    date_threshold = '2024-08-26'
    try:
        # Step 1: Connect and delete records where startdate >= date_threshold
        with engine.connect() as conn:
            
            delete_query = text("TRUNCATE TABLE pgFinalGradeNew")
            conn.execute(delete_query)
            # print(f"Records with startdate >= {date_threshold} have been deleted.")
        # Step 2: Append new data from DataFrame to the table
        df.to_sql('pgFinalGradeNew', con=engine, if_exists='append', index=False)
        print("New data successfully written to the pgFinalGradeNew table.")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # Step 3: Dispose of the engine to close the connection
        engine.dispose()

# Convert 'lastgradeupdate' to datetime if not already
final_df['lastgradeupdate'] = pd.to_datetime(final_df['lastgradeupdate'])
# Group by 'Student_id' and 'course_name' and keep the row with the max 'lastgradeupdate'
#latest_records = final_df.sort_values(by='lastgradeupdate', ascending=False).groupby(['Student_id', 'Course_name'], as_index=False).first()
latest_records = final_df.sort_values(by='lastgradeupdate', ascending=False).groupby(['Student_id', 'Course_name', 'finalgradename'],
                                                                                     as_index=False).first()
latest_records

# final_df.to_csv('final_df.csv', index=False)
import_df_to_db(latest_records)