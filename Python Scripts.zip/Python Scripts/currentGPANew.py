#!/usr/bin/env python3
import requests 
import json
import base64
import xmltodict
import pandas as pd
from sqlalchemy import create_engine, text
from datetime import datetime

print(datetime.now())
def import_dataframe_to_sql():
    client_id = 'Your_Id'
    client_secret = 'Your_Secret'
    auth_header = {}
    auth_data = {}

    """
    Return Access Token to authorize API endpoints
    """
    def get_access_token(client_id, client_secret):
        # # Setting up the URL for authentication
        auth_url = "https://nlcphs.powerschool.com/oauth/access_token/"
        message = f"{client_id}:{client_secret}"

        # The message is encoded to bytes using the ASCII encoding scheme.
        message_bytes = message.encode('ascii')

        # The bytes are then base64 encoded to create a string that will be included in the authentication header.
        base64_bytes = base64.b64encode(message_bytes)

        base64_message = base64_bytes.decode()
        auth_header['Authorization'] = "Basic "+base64_message
        auth_header['Content-Type'] ="application/x-www-form-urlencoded;charset=UTF-8"
        auth_data['grant_type'] = "client_credentials"

        res = requests.post(auth_url, headers=auth_header, data=auth_data)
        response_obj = res.json()
        
        print(response_obj)
        # print(json.dumps(response_obj, indent=2))

        # The access_token is extracted from the response JSON object and stored for use in subsequent requests.
        access_token = response_obj["access_token"]
        return access_token

    token = get_access_token(client_id, client_secret)
    print('Token : ',token)

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json"
    }

    def get_dataframe(records):
        df = pd.DataFrame(records)
        return df

    def class_rank():
        base_url = "https://nlcphs.powerschool.com/ws/schema/table/ClassRank?projection=StudentID,Grade_Level,SchoolID,SchoolName,GPAMethod,GPA,Log"
        all_records = []
        page =1
        pagesize=100
        while True:
            url = f"{base_url}&page={page}&pagesize={pagesize}"
            response = requests.get(url, headers=headers)
            all_data = response.json()
        
            if 'record' in list(all_data.keys()):
                records = all_data['record']
                # print(records)
            if len(records)==0:
                break

            result = [
            {'SchoolID': d['tables']['classrank']['schoolid'],
            'Student_id': d['tables']['classrank']['studentid'],
            'grade_level':d['tables']['classrank']['grade_level'],
            'schoolname': d['tables']['classrank']['schoolname'],
            'log':d['tables']['classrank']['log'],
            'gpamethod': d['tables']['classrank']['gpamethod'],
            'gpa': d['tables']['classrank']['gpa'],
            }
            for d in records]

            df = get_dataframe(result)
            all_records.append(df)

            page+=1
            # pagesize+=100

        dfs = pd.concat(all_records)
        return dfs
    classRank_df = class_rank()

    # classRank_df = classRank_df[classRank_df['gpamethod']=='Current']
    # Extract the desired substring
    classRank_df['extracted_time'] = classRank_df['log'].str.extract(r'\[(\d+/\d+/\d+-\d+:\d+:\d+)-')
    classRank_df['extracted_time'] = pd.to_datetime(classRank_df['extracted_time'], format='%m/%d/%Y-%H:%M:%S')

    classRank_df.drop(columns=['log'], inplace=True)
    classRank_df.rename(columns={'extracted_time':'Date'}, inplace=True)
    # engine = connect_with_connector()
    # with engine.connect() as conn:
    #     # Write the DataFrame to the table
    #     classRank_df.to_sql('currentGPANew', con=conn, if_exists='append', index=False)
    # print("Successfully Imported")
    # return classRank_df
    return classRank_df

classRank_df = import_dataframe_to_sql()
classRank_df.to_csv('class_Data.csv', index=False)

def import_df_to_db(df):
    # Define database credentials separately
    db_user = "inspiroz-user"      

    # This is encoded password
    db_pass = "Your_password" 
    host = "Your_IP"     # replace with actual host IP
    database = "Your_Database_Name" # replace with actual database name

    # Create the connection engine with SQLAlchemy
    engine = create_engine(f"mysql+mysqlconnector://{db_user}:{db_pass}@{host}/{database}")

    try:
        # Step 1: Connect and delete records where startdate >= date_threshold
        with engine.connect() as conn:
            
            delete_query = text("DELETE FROM currentGPANew WHERE DATE(Date) = CURDATE();")
            conn.execute(delete_query)
            # print(f"Records with startdate >= {date_threshold} have been deleted.")
        # Step 2: Append new data from DataFrame to the table
        df.to_sql('currentGPANew', con=engine, if_exists='append', index=False)
        print("New data successfully written to the currentGPANew table.")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # Step 3: Dispose of the engine to close the connection
        engine.dispose()


import_df_to_db(classRank_df)