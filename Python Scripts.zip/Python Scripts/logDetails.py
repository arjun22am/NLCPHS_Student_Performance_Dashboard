#!/usr/bin/env python3
import requests 
import json
import base64
import xmltodict
import pandas as pd
from sqlalchemy import create_engine, text
from datetime import datetime
print("\n#############################################################################################")
print(datetime.now())

client_id = 'Your_Id'
client_secret = 'Your_Secret'
auth_header = {}
auth_data = {}


"""
Return Access Token to authorize API endpoints
"""
def get_access_token(client_id, client_secret):
    # # Setting up the URL for authentication
    auth_url = "https://nlcphs.powerschool.com/oauth/access_token/"
    message = f"{client_id}:{client_secret}"

    # The message is encoded to bytes using the ASCII encoding scheme.
    message_bytes = message.encode('ascii')

    # The bytes are then base64 encoded to create a string that will be included in the authentication header.
    base64_bytes = base64.b64encode(message_bytes)

    base64_message = base64_bytes.decode()
    auth_header['Authorization'] = "Basic "+base64_message
    auth_header['Content-Type'] ="application/x-www-form-urlencoded;charset=UTF-8"
    auth_data['grant_type'] = "client_credentials"

    res = requests.post(auth_url, headers=auth_header, data=auth_data)
    response_obj = res.json()
    
    print(response_obj)
    # print(json.dumps(response_obj, indent=2))

    # The access_token is extracted from the response JSON object and stored for use in subsequent requests.
    access_token = response_obj["access_token"]
    return access_token

token = get_access_token(client_id, client_secret)
print('Token : ',token)


headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/json",
    "Content-Type": "application/json"
}

def get_dataframe(records):
    df = pd.DataFrame(records)
    return df

def logData():
    """
    Fetches paginated final grade data (ID, Student ID, Section ID, Grade, Percent, etc.) from the PowerSchool API, 
    starting from August 1, 2024, and combines it into a DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing all fetched final grade records.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/Log?projection=dcid,ID,StudentID,TeacherID,Entry_Author,Entry_Date,Entry_Time,Category,Subject,Entry,SchoolID,LogTypeID,Subtype,Consequence,Student_Number,Discipline_IncidentType,Discipline_IncidentTypeDetail,Discipline_IncidentDate,Discipline_IncidentContext,Discipline_IncidentLocation,Discipline_IncidentLocDetail,Discipline_Offender,Discipline_Reporter,Discipline_ReporterID,Discipline_VictimType,Discipline_FelonyFlag,Discipline_LikelyInjuryFlag,Discipline_SchoolRulesVioFlag,Discipline_PoliceInvolvedFlag,Discipline_HearingOfficerFlag,Discipline_GangRelatedFlag,Discipline_HateCrimeFlag,Discipline_AlcoholRelatedFlag,Discipline_DrugRelatedFlag,Discipline_DrugTypeDetail,Discipline_WeaponRelatedFlag,Discipline_WeaponType,Discipline_WeaponTypeNotes,Discipline_MoneyLossValue,Discipline_ActionDate,Discipline_ActionTaken,Discipline_ActionTakenDetail,Discipline_DurationAssigned,Discipline_DurationActual,Discipline_DurationNotes,Discipline_Sequence&q=Entry_Date=gt=2024-08-01"

    # &page=2&pagesize=100"
    # response = requests.get(url, headers=headers)
    # data = response.json()
    count = 0
    all_records = []
    page =1
    pagesize=100
    while True:
        # print('Count : ',count)
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        
        if 'record' in list(all_data.keys()):
            records = all_data['record']

        if len(records)==0:
            break

        result = [{
        'id': d['tables']['log']['id'],
        'discipline_policeinvolvedflag': d['tables']['log']['discipline_policeinvolvedflag'],
        'discipline_hearingofficerflag': d['tables']['log']['discipline_hearingofficerflag'],
        'discipline_durationassigned': d['tables']['log']['discipline_durationassigned'],
        'subject': d['tables']['log']['subject'],
        'discipline_moneylossvalue': d['tables']['log']['discipline_moneylossvalue'],
        'discipline_likelyinjuryflag': d['tables']['log']['discipline_likelyinjuryflag'],
        'discipline_hatecrimeflag': d['tables']['log']['discipline_hatecrimeflag'],
        'discipline_durationactual': d['tables']['log']['discipline_durationactual'],
        'discipline_durationnotes': d['tables']['log']['discipline_durationnotes'],
        'entry_date': d['tables']['log']['entry_date'],
        'discipline_drugtypedetail': d['tables']['log']['discipline_drugtypedetail'],
        'teacherid': d['tables']['log']['teacherid'],
        'subtype': d['tables']['log']['subtype'],
        'discipline_felonyflag': d['tables']['log']['discipline_felonyflag'],
        'discipline_alcoholrelatedflag': d['tables']['log']['discipline_alcoholrelatedflag'],
        'discipline_gangrelatedflag': d['tables']['log']['discipline_gangrelatedflag'],
        'entry_author': d['tables']['log']['entry_author'],
        'entry_time': d['tables']['log']['entry_time'],
        'consequence': d['tables']['log']['consequence'],
        'discipline_victimtype': d['tables']['log']['discipline_victimtype'],
        'discipline_drugrelatedflag': d['tables']['log']['discipline_drugrelatedflag'],
        'discipline_reporter': d['tables']['log']['discipline_reporter'],
        'discipline_weaponrelatedflag': d['tables']['log']['discipline_weaponrelatedflag'],
        'discipline_incidenttype': d['tables']['log']['discipline_incidenttype'],
        'discipline_reporterid': d['tables']['log']['discipline_reporterid'],
        'discipline_sequence': d['tables']['log']['discipline_sequence'],
        'logtypeid': d['tables']['log']['logtypeid'],
        'discipline_incidenttypedetail': d['tables']['log']['discipline_incidenttypedetail'],
        'discipline_incidentcontext': d['tables']['log']['discipline_incidentcontext'],
        'discipline_actiontaken': d['tables']['log']['discipline_actiontaken'],
        'discipline_weapontypenotes': d['tables']['log']['discipline_weapontypenotes'],
        'studentid': d['tables']['log']['studentid'],
        'discipline_offender': d['tables']['log']['discipline_offender'],
        'discipline_schoolrulesvioflag': d['tables']['log']['discipline_schoolrulesvioflag'],
        'entry': d['tables']['log']['entry'],
        'dcid': d['tables']['log']['dcid'],
        'student_number': d['tables']['log']['student_number'],
        'schoolid': d['tables']['log']['schoolid'],
        'discipline_actiontakendetail': d['tables']['log']['discipline_actiontakendetail'],
        'discipline_incidentlocdetail': d['tables']['log']['discipline_incidentlocdetail'],
        'category': d['tables']['log']['category'],
        'discipline_incidentlocation': d['tables']['log']['discipline_incidentlocation'],
        'discipline_weapontype': d['tables']['log']['discipline_weapontype'],
    } for d in records]


        df = get_dataframe(result)
        # print(df)
        all_records.append(df)

        page+=1
        count+=1
    dfs = pd.concat(all_records)
    return dfs

log_df = logData()

def PdtAction():
    """
    Fetches paginated final grade data (ID, Student ID, Section ID, Grade, Percent, etc.) from the PowerSchool API, 
    starting from August 1, 2024, and combines it into a DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing all fetched final grade records.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/U_PDT_ACTIONS?projection=LOGDCID,ACTION_TYPE,ADMIN_ACTION,EMAIL_RECIPIENT_ADDRESS,EMAIL_RECIPIENT_ROLE,ENTRY_TYPE,Log_Action1_Author,Log_Action1_Date,Log_Action1_Note,Log_Action1_Type,Log_Action2_Author,Log_Action2_Date,Log_Action2_Note,Log_Action2_Type,Log_Action3_Author,Log_Action3_Date,Log_Action3_Note,Log_Action3_Type,PBIS_ACTION1,PBIS_ACTION1_DURATION,PBIS_Admin_Action,PBIS_Admin_Action_Dur,PBIS_Behavior_Point,PBIS_CONSEQUENCE1,PBIS_Consequence1_Dur,PBIS_CONSEQUENCE1_DURATION,PBIS_ConsequenceServe,PBIS_CONSEQUENCESERVED,PBIS_CONSEQUENCESERVED_DUR,PBIS_CS_Duration,PBIS_OTHER_ACTIONS,PBIS_Teacher_Action,PBIS_Teacher_Action_Dur"

    # &page=2&pagesize=100"
    # response = requests.get(url, headers=headers)
    # data = response.json()
    count = 0
    all_records = []
    page =1
    pagesize=100
    while True:
        #print('Count : ',count)
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        
        if 'record' in list(all_data.keys()):
            records = all_data['record']

        if len(records)==0:
            break

        result = [
            {
                'logdcid': d.get('tables', {}).get('u_pdt_actions', {}).get('logdcid'),
                'action_type': d.get('tables', {}).get('u_pdt_actions', {}).get('action_type'),
                'admin_action': d.get('tables', {}).get('u_pdt_actions', {}).get('admin_action'),
                'email_recipient_address': d.get('tables', {}).get('u_pdt_actions', {}).get('email_recipient_address'),
                'email_recipient_role': d.get('tables', {}).get('u_pdt_actions', {}).get('email_recipient_role'),
                'entry_type': d.get('tables', {}).get('u_pdt_actions', {}).get('entry_type'),
                'log_action1_author': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action1_author'),
                'log_action1_date': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action1_date'),
                'log_action1_note': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action1_note'),
                'log_action1_type': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action1_type'),
                'log_action2_author': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action2_author'),
                'log_action2_date': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action2_date'),
                'log_action2_note': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action2_note'),
                'log_action2_type': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action2_type'),
                'log_action3_author': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action3_author'),
                'log_action3_date': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action3_date'),
                'log_action3_note': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action3_note'),
                'log_action3_type': d.get('tables', {}).get('u_pdt_actions', {}).get('log_action3_type'),
                'pbis_action1': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_action1'),
                'pbis_action1_duration': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_action1_duration'),
                'pbis_admin_action': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_admin_action'),
                'pbis_admin_action_dur': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_admin_action_dur'),
                'pbis_behavior_point': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_behavior_point'),
                'pbis_consequence1': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_consequence1'),
                'pbis_consequence1_dur': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_consequence1_dur'),
                'pbis_consequence1_duration': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_consequence1_duration'),
                'pbis_consequenceserve': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_consequenceserve'),
                'pbis_consequenceserved': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_consequenceserved'),
                'pbis_consequenceserved_dur': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_consequenceserved_dur'),
                'pbis_cs_duration': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_cs_duration'),
                'pbis_other_actions': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_other_actions'),
                'pbis_teacher_action': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_teacher_action'),
                'pbis_teacher_action_dur': d.get('tables', {}).get('u_pdt_actions', {}).get('pbis_teacher_action_dur'),
            }
            for d in records
        ]



        df = get_dataframe(result)
        # print(df)
        all_records.append(df)

        page+=1
        count+=1
    dfs = pd.concat(all_records)
    return dfs

pdtActionDf = PdtAction()

result_df = pd.merge(log_df, pdtActionDf, left_on='dcid', right_on='logdcid', how='left')
print(len(result_df))

def import_df_to_db(df):
    # Define database credentials separately
    db_user = "Your_username"      

    # This is encoded password
    db_pass = "Your_password" 
    host = "Your_IP"     # replace with actual host IP
    database = "Your_Database_Name" # replace with actual database name

    # Create the connection engine with SQLAlchemy
    engine = create_engine(f"mysql+mysqlconnector://{db_user}:{db_pass}@{host}/{database}")
    try:
        # # Step 1: Connect and delete records where startdate >= date_threshold
        with engine.connect() as conn:
            
            delete_query = text("TRUNCATE TABLE logDetails")
            conn.execute(delete_query)
            # print(f"Records with startdate >= {date_threshold} have been deleted.")
        # Step 2: Append new data from DataFrame to the table
        df.to_sql('logDetails', con=engine, if_exists='append', index=False)
        print("New data successfully written to the logDetails table.")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # Step 3: Dispose of the engine to close the connection
        engine.dispose()

import_df_to_db(result_df)