#!/usr/bin/env python3
import requests 
import json
import base64
import xmltodict
import pandas as pd
from sqlalchemy import create_engine, text
import datetime
print("\n###################################################################################")
print("date : ",datetime.datetime.now())
client_id = 'Your_Id'
client_secret = 'Your_Secret'
auth_header = {}
auth_data = {}

"""
Return Access Token to authorize API endpoints
"""
def get_access_token(client_id, client_secret):
    # # Setting up the URL for authentication
    auth_url = "https://nlcphs.powerschool.com/oauth/access_token/"
    message = f"{client_id}:{client_secret}"

    # The message is encoded to bytes using the ASCII encoding scheme.
    message_bytes = message.encode('ascii')

    # The bytes are then base64 encoded to create a string that will be included in the authentication header.
    base64_bytes = base64.b64encode(message_bytes)

    base64_message = base64_bytes.decode()
    auth_header['Authorization'] = "Basic "+base64_message
    auth_header['Content-Type'] ="application/x-www-form-urlencoded;charset=UTF-8"
    auth_data['grant_type'] = "client_credentials"

    res = requests.post(auth_url, headers=auth_header, data=auth_data)
    response_obj = res.json()
    
    print(response_obj)
    # print(json.dumps(response_obj, indent=2))

    # The access_token is extracted from the response JSON object and stored for use in subsequent requests.
    access_token = response_obj["access_token"]
    return access_token

token = get_access_token(client_id, client_secret)
print('Token : ',token)


headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/json",
    "Content-Type": "application/json"
}

def get_dataframe(records):
    df = pd.DataFrame(records)
    return df

def CC_data():
    """
    Fetches course data (ID, School ID, Course Number, Course Name) from a paginated API and combines it into a DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing all course records.
    """
    #base_url = "https://nlcphs.powerschool.com/ws/schema/table/CC?projection=ID,StudentID,SectionID,Section_Number,CurrentAbsences,CurrentTardies,TeacherID,Course_Number,TermID,SchoolID,DateEnrolled,DateLeft,LastAttMod,TRANSACTION_DATE&q=TermID=gt=3399"
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/CC?projection=ID,StudentID,SectionID,Section_Number,CurrentAbsences,CurrentTardies,TeacherID,Course_Number,TermID,SchoolID,DateEnrolled,DateLeft,LastAttMod,TRANSACTION_DATE&q=TermID=gt=3399"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        # print(all_data)
        if 'record' in list(all_data.keys()):
            records = all_data['record']
        if len(records)==0:
            break

        result = [{
            'id': d['tables']['cc']['id'],
            'studentid':d['tables']['cc']['studentid'],
            'sectionid':d['tables']['cc']['sectionid'],
            'schoolid':d['tables']['cc']['schoolid'],
            'transaction_date':d['tables']['cc']['transaction_date'],
            'currentabsences':d['tables']['cc']['currentabsences'],
            'currenttardies':d['tables']['cc']['currenttardies'],
            'course_number':d['tables']['cc']['course_number'],
            'termid':d['tables']['cc']['termid'],
            'teacherid':d['tables']['cc']['teacherid'],
            'dateenrolled':d['tables']['cc']['dateenrolled'],
            'section_number':d['tables']['cc']['section_number'],
            'dateleft':d['tables']['cc']['dateleft'],
        }
         for d in records
         ]  
        df = get_dataframe(result)
        all_records.append(df)

        page+=1
    dfs = pd.concat(all_records)
    return dfs

cc_df = CC_data()

def student_data():
    """
    Fetches paginated student data (School ID, Name, Student Number, Grade, etc.) from the PowerSchool API, 
    filters for enrolled students, and returns a formatted DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing enrolled student records with columns: SchoolID, Student Name, 
                      Student_id, Student_Number, and Grade_level.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/Students?projection=SchoolID,ID,DCID,Student_Number,Student_AllowWebAccess,First_Name,Last_Name,Grade_Level,Student_Web_ID,Student_Web_Password,State_StudentNumber,Gender,DOB,Enroll_Status,Street,City,State,Zip,Emerg_Contact_1,Guardian_StudentCont_guid,Web_ID,Web_Password,FedEthnicity,LunchStatus&q=Enroll_Status==0"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        if 'record' in list(all_data.keys()):
            records = all_data['record']
        if len(records)==0:
            break

        result = [
        {'SchoolID': d['tables']['students']['schoolid'],
         'Last_Name': d['tables']['students']['last_name'],
         'First_Name': d['tables']['students']['first_name'],
         'Student_id': d['tables']['students']['id'],
         'Student_Number': d['tables']['students']['student_number'],
         'Grade':d['tables']['students']['grade_level'],
         'Enroll_Status': d['tables']['students']['enroll_status'],
        }
        for d in records]

        df = get_dataframe(result)
        all_records.append(df)

        page+=1


    dfs = pd.concat(all_records)
    dfs['Student Name'] = dfs['Last_Name']+ ' '+dfs['First_Name']
    # Create a copy of the subset where Enroll_Status is '0'
    # student_df = dfs[dfs['Enroll_Status'] == '0'].copy()
    student_df = dfs
    # Drop unnecessary columns
    student_df.drop(columns=['Last_Name', 'First_Name', 'Enroll_Status'], inplace=True)

    # Rename the 'Grade' column to 'Grade_level'
    student_df.rename(columns={'Grade': 'Grade_level'}, inplace=True)
    return student_df

student_df = student_data()

attendance_df = pd.merge(cc_df, student_df, left_on='studentid', right_on='Student_id', how='left')

def course_data():
    """
    Fetches course data (ID, School ID, Course Number, Course Name) from a paginated API and combines it into a DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing all course records.
    """
    base_url = "https://nlcphs.powerschool.com/ws/schema/table/Courses?projection=ID,SchoolID,Course_Name,Course_Number"
    all_records = []
    page =1
    pagesize=100
    while True:
        url = f"{base_url}&page={page}&pagesize={pagesize}"
        response = requests.get(url, headers=headers)
        all_data = response.json()
        if 'record' in list(all_data.keys()):
            records = all_data['record']
        if len(records)==0:
            break

        result = [{
            'ID': d['tables']['courses']['id'],
            'School_id':d['tables']['courses']['schoolid'],
            'Course_number':d['tables']['courses']['course_number'],
            'Course_name':d['tables']['courses']['course_name'],
        }
         for d in records
         ]  
        df = get_dataframe(result)
        all_records.append(df)

        page+=1
    dfs = pd.concat(all_records)
    return dfs

course_df = course_data()

attendance_course = pd.merge(attendance_df, course_df, left_on='course_number', right_on='Course_number', how='left')

attendance_course.drop(columns=['School_id', 'Course_number', 'ID', 'schoolid'], inplace=True)

def import_df_to_db(df):
    # Define database credentials separately
    db_user = "your_username"      

    # This is encoded password
    db_pass = "Your_password" 
    host = "Your_IP"     # replace with actual host IP
    database = "Your_Database_Name" # replace with actual database name

    # Create the connection engine with SQLAlchemy
    engine = create_engine(f"mysql+mysqlconnector://{db_user}:{db_pass}@{host}/{database}")
    try:
        # # Step 1: Connect and delete records where startdate >= date_threshold
        with engine.connect() as conn:
            
            delete_query = text("TRUNCATE TABLE Period_Attendance_New")
            conn.execute(delete_query)
            # print(f"Records with startdate >= {date_threshold} have been deleted.")
        # Step 2: Append new data from DataFrame to the table
        df.to_sql('Period_Attendance_New', con=engine, if_exists='append', index=False)
        print("New data successfully written to the Period_Attendance_New table.")

    except Exception as e:
        print(f"An error occurred: {e}")

    finally:
        # Step 3: Dispose of the engine to close the connection
        engine.dispose()

import_df_to_db(attendance_course)